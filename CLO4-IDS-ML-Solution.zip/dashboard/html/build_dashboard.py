"""
build_dashboard.py
--------------------
Assembles the final, fully offline `ids_dashboard.html` from:
  - index_template.html   (page markup, CSS, and dashboard JS logic)
  - Chart.js + PapaParse   (fetched via npm, then inlined -- no CDN at runtime)
  - model_data.json        (produced by export_for_html.py at the repo root)

Run from the dashboard_html/ directory:

    npm install chart.js papaparse --no-save
    python3 build_dashboard.py

Requires model_data.json to already exist (run export_for_html.py first).
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def ensure_libs():
    chart_path = os.path.join(HERE, "node_modules/chart.js/dist/chart.umd.min.js")
    papa_path = os.path.join(HERE, "node_modules/papaparse/papaparse.min.js")
    if not (os.path.exists(chart_path) and os.path.exists(papa_path)):
        print("Installing chart.js and papaparse via npm...")
        subprocess.run(["npm", "install", "chart.js", "papaparse", "--no-save", "--silent"],
                        cwd=HERE, check=True)
    return chart_path, papa_path


def main():
    model_data_path = os.path.join(HERE, "model_data.json")
    if not os.path.exists(model_data_path):
        sys.exit("model_data.json not found. Run export_for_html.py from the repo root first.")

    chart_path, papa_path = ensure_libs()

    with open(os.path.join(HERE, "index_template.html"), "r", encoding="utf-8") as f:
        html = f.read()
    with open(chart_path, "r", encoding="utf-8") as f:
        chartjs_src = f.read()
    with open(papa_path, "r", encoding="utf-8") as f:
        papaparse_src = f.read()
    with open(model_data_path, "r", encoding="utf-8") as f:
        model_json = f.read()

    html = html.replace("/*__CHART_JS__*/", chartjs_src)
    html = html.replace("/*__PAPAPARSE__*/", papaparse_src)
    html = html.replace("/*__MODEL_DATA__*/", "const MODEL_DATA = " + model_json + ";")

    out_path = os.path.join(HERE, "ids_dashboard.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    size_mb = os.path.getsize(out_path) / (1024 * 1024)
    print(f"Wrote {out_path} ({size_mb:.2f} MB). Zero external dependencies at runtime.")


if __name__ == "__main__":
    main()
