"""
AI-Powered Intrusion Detection Dashboard
------------------------------------------
Local Streamlit app for the "AI-Powered Intrusion Detection System using
Random Forest and CIC-IDS2017" project. Run locally with:

    streamlit run app.py

Pages: Dashboard, Data Explorer, Model Training, Visualizations,
Predictions, Model History, Settings.
"""

import io
import time
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_auc_score, roc_curve,
)

sns.set_theme(style="whitegrid")

DEFAULT_DATA_PATH = "data/network_traffic_raw.csv"
NON_FEATURE_COLS = {"Label", "Protocol", "Binary_Label", "Protocol_enc"}

st.set_page_config(
    page_title="AI-Powered IDS Dashboard",
    page_icon=":shield:",
    layout="wide",
)

# ----------------------------------------------------------------------
# Session state initialization
# ----------------------------------------------------------------------
defaults = {
    "raw_df": None,
    "data_source_label": None,
    "clean_df": None,
    "feature_cols": None,
    "protocol_encoder": None,
    "scaler": None,
    "median_values": None,
    "model": None,
    "model_name": None,
    "model_params": None,
    "X_test": None,
    "y_test": None,
    "y_pred": None,
    "y_proba": None,
    "metrics": None,
    "history": [],
    "history_counter": 0,
}
for key, val in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = val


# ----------------------------------------------------------------------
# Data helpers
# ----------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_default_data(path):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    return df


def preprocess(df):
    """Clean, encode, and return the dataframe plus fitted encoder / medians."""
    df = df.copy()
    df.replace([np.inf, -np.inf], np.nan, inplace=True)

    numeric_cols = [c for c in df.select_dtypes(include=[np.number]).columns]
    medians = {}
    for col in numeric_cols:
        if df[col].isna().any():
            med = df[col].median()
            df[col] = df[col].fillna(med)
            medians[col] = med
        else:
            medians[col] = df[col].median()

    protocol_encoder = LabelEncoder()
    if "Protocol" in df.columns:
        df["Protocol_enc"] = protocol_encoder.fit_transform(df["Protocol"].astype(str))
    else:
        df["Protocol_enc"] = 0

    if "Label" in df.columns:
        df["Binary_Label"] = np.where(df["Label"] == "BENIGN", 0, 1)
    else:
        df["Binary_Label"] = 0

    feature_cols = numeric_cols + ["Protocol_enc"]
    return df, feature_cols, protocol_encoder, medians


def ensure_data_loaded():
    if st.session_state.raw_df is None:
        df = load_default_data(DEFAULT_DATA_PATH)
        st.session_state.raw_df = df
        st.session_state.data_source_label = f"Bundled sample ({DEFAULT_DATA_PATH})"
        clean_df, feature_cols, encoder, medians = preprocess(df)
        st.session_state.clean_df = clean_df
        st.session_state.feature_cols = feature_cols
        st.session_state.protocol_encoder = encoder
        st.session_state.median_values = medians


def reset_session():
    for key, val in defaults.items():
        st.session_state[key] = val


ALGOS = {
    "Random Forest": RandomForestClassifier,
    "Decision Tree": DecisionTreeClassifier,
    "Logistic Regression": LogisticRegression,
}


def build_model(algo_name, params):
    if algo_name == "Random Forest":
        return RandomForestClassifier(
            n_estimators=params["n_estimators"],
            max_depth=params["max_depth"],
            min_samples_leaf=params["min_samples_leaf"],
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
        )
    if algo_name == "Decision Tree":
        return DecisionTreeClassifier(
            max_depth=params["max_depth"],
            min_samples_leaf=params["min_samples_leaf"],
            class_weight="balanced",
            random_state=42,
        )
    if algo_name == "Logistic Regression":
        return LogisticRegression(
            C=params["C"], max_iter=1000, class_weight="balanced",
        )
    raise ValueError(algo_name)


# ----------------------------------------------------------------------
# Sidebar navigation
# ----------------------------------------------------------------------
st.sidebar.title(":shield: AI-Powered IDS")
st.sidebar.caption("Random Forest + CIC-IDS2017-style traffic")

page = st.sidebar.radio(
    "Navigate",
    ["Dashboard", "Data Explorer", "Model Training", "Visualizations", "Predictions", "Model History", "Settings"],
    label_visibility="collapsed",
)

ensure_data_loaded()

st.sidebar.markdown("---")
if st.session_state.raw_df is not None:
    st.sidebar.caption(f"Current dataset: {st.session_state.data_source_label}")
    st.sidebar.caption(f"Rows: {len(st.session_state.raw_df):,} | Features: {len(st.session_state.feature_cols)}")
if st.session_state.model is not None:
    st.sidebar.success(f"Active model: {st.session_state.model_name}")
else:
    st.sidebar.info("No model trained yet")

if st.sidebar.button("New Session", width="stretch"):
    reset_session()
    st.rerun()


# ----------------------------------------------------------------------
# PAGE: Dashboard
# ----------------------------------------------------------------------
if page == "Dashboard":
    st.title("Dashboard")
    st.caption("Overview of the current dataset and, once trained, the active detection model.")

    df = st.session_state.raw_df
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Flows", f"{len(df):,}")
    col2.metric("Features", len(st.session_state.feature_cols))
    n_classes = df["Label"].nunique() if "Label" in df.columns else "n/a"
    col3.metric("Traffic Classes", n_classes)
    attack_share = (df["Label"] != "BENIGN").mean() * 100 if "Label" in df.columns else 0
    col4.metric("Malicious Share", f"{attack_share:.1f}%")

    st.markdown("### Traffic Split")
    c1, c2 = st.columns([1, 2])
    with c1:
        binary_counts = np.where(df["Label"] == "BENIGN", "BENIGN", "ATTACK")
        fig, ax = plt.subplots(figsize=(4, 4))
        pd.Series(binary_counts).value_counts().plot.pie(
            autopct="%1.1f%%", colors=["#4C72B0", "#C44E52"], ylabel="", ax=ax
        )
        ax.set_title("Benign vs. Malicious")
        st.pyplot(fig, width="content")
        plt.close(fig)
    with c2:
        order = df["Label"].value_counts().index
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.countplot(data=df, y="Label", order=order, hue="Label", palette="viridis", legend=False, ax=ax)
        ax.set_xscale("log")
        ax.set_title("Flows by Class (log scale)")
        st.pyplot(fig, width="stretch")
        plt.close(fig)

    st.markdown("### Active Model Snapshot")
    if st.session_state.metrics is None:
        st.warning("No model trained in this session yet. Go to Model Training to train one.")
    else:
        m = st.session_state.metrics
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Accuracy", f"{m['accuracy']*100:.2f}%")
        c2.metric("Precision", f"{m['precision']*100:.2f}%")
        c3.metric("Recall", f"{m['recall']*100:.2f}%")
        c4.metric("F1 Score", f"{m['f1']*100:.2f}%")
        c5.metric("ROC AUC", f"{m['auc']*100:.2f}%")
        st.caption(f"Model: {st.session_state.model_name} | Trained on {m['n_train']:,} flows | Tested on {m['n_test']:,} flows")


# ----------------------------------------------------------------------
# PAGE: Data Explorer
# ----------------------------------------------------------------------
elif page == "Data Explorer":
    st.title("Data Explorer")

    df = st.session_state.raw_df
    st.markdown(f"**Rows:** {len(df):,} &nbsp;&nbsp; **Columns:** {df.shape[1]} &nbsp;&nbsp; "
                f"**Missing values:** {int(df.isna().sum().sum())}")

    with st.expander("Filter data", expanded=True):
        c1, c2 = st.columns(2)
        with c1:
            labels = ["(all)"] + sorted(df["Label"].unique().tolist()) if "Label" in df.columns else ["(all)"]
            label_filter = st.selectbox("Traffic class", labels)
        with c2:
            protocols = ["(all)"] + sorted(df["Protocol"].unique().tolist()) if "Protocol" in df.columns else ["(all)"]
            protocol_filter = st.selectbox("Protocol", protocols)

    view = df.copy()
    if "Label" in df.columns and label_filter != "(all)":
        view = view[view["Label"] == label_filter]
    if "Protocol" in df.columns and protocol_filter != "(all)":
        view = view[view["Protocol"] == protocol_filter]

    st.dataframe(view.head(500), width="stretch", height=380)
    st.caption(f"Showing up to 500 of {len(view):,} matching rows.")

    st.markdown("### Summary Statistics")
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    display_stats = view[numeric_cols].replace([np.inf, -np.inf], np.nan)
    st.dataframe(display_stats.describe().T, width="stretch")

    st.markdown("### Missing / Invalid Values by Column")
    miss = df.replace([np.inf, -np.inf], np.nan).isna().sum()
    miss = miss[miss > 0].sort_values(ascending=False)
    if len(miss) == 0:
        st.success("No missing or infinite values detected.")
    else:
        st.dataframe(miss.rename("Missing / Infinite Count"), width="stretch")


# ----------------------------------------------------------------------
# PAGE: Model Training
# ----------------------------------------------------------------------
elif page == "Model Training":
    st.title("Model Training")

    df = st.session_state.clean_df
    feature_cols = st.session_state.feature_cols

    st.markdown("### Algorithm Configuration")
    algo_name = st.selectbox("Algorithm", list(ALGOS.keys()), index=0)

    params = {}
    c1, c2, c3 = st.columns(3)
    if algo_name in ("Random Forest", "Decision Tree"):
        with c1:
            params["max_depth"] = st.slider("Max depth", 2, 30, 18)
        with c2:
            params["min_samples_leaf"] = st.slider("Min samples per leaf", 1, 10, 2)
        if algo_name == "Random Forest":
            with c3:
                params["n_estimators"] = st.slider("Number of trees", 50, 400, 200, step=25)
    else:
        with c1:
            params["C"] = st.select_slider("Regularization C", options=[0.01, 0.1, 1.0, 10.0, 100.0], value=1.0)

    st.markdown("### Training Settings")
    c1, c2 = st.columns(2)
    with c1:
        test_size = st.slider("Test split (%)", 10, 40, 25) / 100
    with c2:
        st.caption("Class balance is preserved via stratified sampling on the BENIGN / ATTACK label.")

    if st.button("Train Model", type="primary", width="stretch"):
        progress = st.progress(0, text="Preparing features...")

        X = df[feature_cols]
        y = df["Binary_Label"]
        scaler = StandardScaler()
        X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)
        progress.progress(25, text="Splitting train/test sets...")

        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=test_size, random_state=42, stratify=y
        )
        progress.progress(45, text=f"Training {algo_name}...")

        model = build_model(algo_name, params)
        model.fit(X_train, y_train)
        progress.progress(80, text="Evaluating on test set...")

        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else y_pred

        metrics = {
            "accuracy": accuracy_score(y_test, y_pred),
            "precision": precision_score(y_test, y_pred, zero_division=0),
            "recall": recall_score(y_test, y_pred, zero_division=0),
            "f1": f1_score(y_test, y_pred, zero_division=0),
            "auc": roc_auc_score(y_test, y_proba),
            "n_train": len(X_train),
            "n_test": len(X_test),
        }
        progress.progress(100, text="Done.")
        time.sleep(0.2)
        progress.empty()

        st.session_state.scaler = scaler
        st.session_state.model = model
        st.session_state.model_name = algo_name
        st.session_state.model_params = params
        st.session_state.X_test = X_test
        st.session_state.y_test = y_test
        st.session_state.y_pred = y_pred
        st.session_state.y_proba = y_proba
        st.session_state.metrics = metrics

        st.session_state.history_counter += 1
        st.session_state.history.append({
            "id": st.session_state.history_counter,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "algorithm": algo_name,
            "params": params,
            "accuracy": metrics["accuracy"],
            "precision": metrics["precision"],
            "recall": metrics["recall"],
            "f1": metrics["f1"],
            "auc": metrics["auc"],
            "dataset": st.session_state.data_source_label,
        })

        st.success(f"{algo_name} trained successfully.")
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Accuracy", f"{metrics['accuracy']*100:.2f}%")
        c2.metric("Precision", f"{metrics['precision']*100:.2f}%")
        c3.metric("Recall", f"{metrics['recall']*100:.2f}%")
        c4.metric("F1 Score", f"{metrics['f1']*100:.2f}%")
        c5.metric("ROC AUC", f"{metrics['auc']*100:.2f}%")
        st.caption("See the Visualizations page for the confusion matrix, ROC curve, and feature importance.")


# ----------------------------------------------------------------------
# PAGE: Visualizations
# ----------------------------------------------------------------------
elif page == "Visualizations":
    st.title("Visualizations")

    if st.session_state.model is None:
        st.warning("Train a model on the Model Training page first to unlock the evaluation charts below.")
    else:
        model = st.session_state.model
        y_test = st.session_state.y_test
        y_pred = st.session_state.y_pred
        y_proba = st.session_state.y_proba
        feature_cols = st.session_state.feature_cols

        c1, c2 = st.columns(2)

        with c1:
            st.markdown("#### Confusion Matrix")
            cm = confusion_matrix(y_test, y_pred)
            fig, ax = plt.subplots(figsize=(5, 4.2))
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                        xticklabels=["BENIGN", "ATTACK"], yticklabels=["BENIGN", "ATTACK"], ax=ax)
            ax.set_xlabel("Predicted Label")
            ax.set_ylabel("True Label")
            st.pyplot(fig, width="stretch")
            plt.close(fig)

        with c2:
            st.markdown("#### ROC Curve")
            fpr, tpr, _ = roc_curve(y_test, y_proba)
            auc = st.session_state.metrics["auc"]
            fig, ax = plt.subplots(figsize=(5, 4.2))
            ax.plot(fpr, tpr, color="#C44E52", lw=2.2, label=f"{st.session_state.model_name} (AUC = {auc:.3f})")
            ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random Guess")
            ax.set_xlabel("False Positive Rate")
            ax.set_ylabel("True Positive Rate")
            ax.legend(loc="lower right", fontsize=8)
            st.pyplot(fig, width="stretch")
            plt.close(fig)

        st.markdown("#### Feature Importance")
        if hasattr(model, "feature_importances_"):
            importances = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False).head(12)
            fig, ax = plt.subplots(figsize=(9, 5))
            sns.barplot(x=importances.values, y=importances.index, hue=importances.index, palette="crest", legend=False, ax=ax)
            ax.set_xlabel("Relative Importance")
            ax.set_ylabel("Feature")
            st.pyplot(fig, width="stretch")
            plt.close(fig)
        else:
            st.info(f"{st.session_state.model_name} does not expose feature importances (available for Random Forest and Decision Tree).")

        if len(st.session_state.history) > 1:
            st.markdown("#### Model Accuracy Comparison (this session)")
            hist_df = pd.DataFrame(st.session_state.history)
            latest_per_algo = hist_df.sort_values("id").groupby("algorithm").last().reset_index()
            fig, ax = plt.subplots(figsize=(8, 3.5))
            sns.barplot(data=latest_per_algo, x="accuracy", y="algorithm", hue="algorithm", palette="mako", legend=False, ax=ax)
            ax.set_xlim(0, 1)
            ax.set_xlabel("Accuracy")
            ax.set_ylabel("")
            st.pyplot(fig, width="stretch")
            plt.close(fig)

        st.markdown("#### Feature Correlation Heatmap (raw data)")
        with st.expander("Show correlation heatmap"):
            numeric_cols_raw = st.session_state.raw_df.select_dtypes(include=[np.number]).columns.tolist()
            corr = st.session_state.raw_df[numeric_cols_raw].replace([np.inf, -np.inf], np.nan).corr()
            fig, ax = plt.subplots(figsize=(11, 9))
            sns.heatmap(corr, cmap="coolwarm", center=0, square=True, cbar_kws={"shrink": 0.7}, ax=ax)
            ax.tick_params(labelsize=7)
            plt.setp(ax.get_xticklabels(), rotation=90)
            st.pyplot(fig, width="stretch")
            plt.close(fig)


# ----------------------------------------------------------------------
# PAGE: Predictions
# ----------------------------------------------------------------------
elif page == "Predictions":
    st.title("Predictions")

    if st.session_state.model is None:
        st.warning("Train a model on the Model Training page first.")
    else:
        model = st.session_state.model
        scaler = st.session_state.scaler
        feature_cols = st.session_state.feature_cols
        medians = st.session_state.median_values
        encoder = st.session_state.protocol_encoder
        df = st.session_state.clean_df

        tab1, tab2 = st.tabs(["Manual Input", "Batch Prediction (Upload CSV)"])

        with tab1:
            st.caption("Enter values for the flow features shown below. Other features use the dataset median.")
            top_features = ["Subflow Fwd Bytes", "Flow IAT Std", "Total Backward Packets",
                             "Flow Bytes/s", "Total Fwd Packets", "SYN Flag Count", "Flow Duration"]
            top_features = [f for f in top_features if f in df.columns]

            input_vals = {}
            cols = st.columns(3)
            for i, feat in enumerate(top_features):
                default = float(df[feat].median())
                with cols[i % 3]:
                    input_vals[feat] = st.number_input(feat, value=round(default, 2))

            protocol_val = st.selectbox("Protocol", list(encoder.classes_) if encoder is not None else ["TCP"])

            if st.button("Predict", type="primary"):
                row = {c: medians.get(c, 0.0) for c in feature_cols if c != "Protocol_enc"}
                row.update(input_vals)
                proto_enc = encoder.transform([protocol_val])[0] if encoder is not None else 0
                row["Protocol_enc"] = proto_enc

                X_row = pd.DataFrame([row])[feature_cols]
                X_row_scaled = pd.DataFrame(scaler.transform(X_row), columns=feature_cols)
                pred = model.predict(X_row_scaled)[0]
                proba = model.predict_proba(X_row_scaled)[0] if hasattr(model, "predict_proba") else [1 - pred, pred]
                label = "ATTACK" if pred == 1 else "BENIGN"
                confidence = proba[int(pred)] * 100

                if pred == 1:
                    st.error(f"Result: **{label}** ({confidence:.1f}% confidence)")
                else:
                    st.success(f"Result: **{label}** ({confidence:.1f}% confidence)")

        with tab2:
            st.caption("Upload a CSV with the same columns as the training data "
                       "(numeric flow features plus a Protocol column).")
            uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
            if uploaded is not None:
                batch_df = pd.read_csv(uploaded)
                batch_df.columns = [c.strip() for c in batch_df.columns]

                work = batch_df.copy()
                work.replace([np.inf, -np.inf], np.nan, inplace=True)
                for col in feature_cols:
                    if col == "Protocol_enc":
                        continue
                    if col not in work.columns:
                        work[col] = medians.get(col, 0.0)
                    work[col] = work[col].fillna(medians.get(col, work[col].median()))

                if "Protocol" in work.columns and encoder is not None:
                    known = set(encoder.classes_)
                    work["Protocol_enc"] = work["Protocol"].apply(
                        lambda p: encoder.transform([p])[0] if p in known else 0
                    )
                else:
                    work["Protocol_enc"] = 0

                X_batch = work[feature_cols]
                X_batch_scaled = pd.DataFrame(scaler.transform(X_batch), columns=feature_cols)
                preds = model.predict(X_batch_scaled)
                probas = model.predict_proba(X_batch_scaled) if hasattr(model, "predict_proba") else None

                result = batch_df.copy()
                result["Predicted"] = np.where(preds == 1, "ATTACK", "BENIGN")
                if probas is not None:
                    result["Confidence"] = [f"{p[int(pr)]*100:.1f}%" for p, pr in zip(probas, preds)]

                st.dataframe(result.head(200), width="stretch", height=350)
                st.caption(f"Showing up to 200 of {len(result):,} predicted rows.")

                csv_bytes = result.to_csv(index=False).encode("utf-8")
                st.download_button("Download Results", data=csv_bytes,
                                    file_name="ids_predictions.csv", mime="text/csv")


# ----------------------------------------------------------------------
# PAGE: Model History
# ----------------------------------------------------------------------
elif page == "Model History":
    st.title("Model Performance History")
    st.caption("Models trained during this session (in-memory, cleared on New Session).")

    if not st.session_state.history:
        st.info("No models trained yet.")
    else:
        hist_df = pd.DataFrame(st.session_state.history)
        display_df = hist_df[["id", "timestamp", "algorithm", "accuracy", "precision", "recall", "f1", "auc"]].copy()
        for col in ["accuracy", "precision", "recall", "f1", "auc"]:
            display_df[col] = (display_df[col] * 100).round(2).astype(str) + "%"
        st.dataframe(display_df, width="stretch", height=300)

        st.markdown("### Load or Remove a Model")
        selected_id = st.selectbox("Select a run by ID", hist_df["id"].tolist())
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Load Selected Model", width="stretch"):
                st.warning(
                    "Loading a past run re-trains it with the same algorithm and settings, "
                    "since only the current run's fitted model is kept in memory. "
                    "Use Model Training with the same settings to reproduce it exactly."
                )
        with c2:
            if st.button("Delete Selected Run", width="stretch"):
                st.session_state.history = [h for h in st.session_state.history if h["id"] != selected_id]
                st.rerun()

        if st.button("Clear All History", width="stretch"):
            st.session_state.history = []
            st.rerun()


# ----------------------------------------------------------------------
# PAGE: Settings
# ----------------------------------------------------------------------
elif page == "Settings":
    st.title("Settings")

    st.markdown("### Dataset")
    st.caption(f"Current dataset: {st.session_state.data_source_label}")
    st.caption(f"Rows: {len(st.session_state.raw_df):,} | Missing values: "
               f"{int(st.session_state.raw_df.isna().sum().sum())}")

    uploaded = st.file_uploader(
        "Upload a replacement CSV (must include a Label and Protocol column, "
        "matching the CIC-IDS2017-style schema)", type=["csv"]
    )
    if uploaded is not None:
        if st.button("Use Uploaded Dataset"):
            new_df = pd.read_csv(uploaded)
            new_df.columns = [c.strip() for c in new_df.columns]
            st.session_state.raw_df = new_df
            st.session_state.data_source_label = f"Uploaded file ({uploaded.name})"
            clean_df, feature_cols, encoder, medians = preprocess(new_df)
            st.session_state.clean_df = clean_df
            st.session_state.feature_cols = feature_cols
            st.session_state.protocol_encoder = encoder
            st.session_state.median_values = medians
            st.session_state.model = None
            st.session_state.metrics = None
            st.success("Dataset replaced. Go to Model Training to train on the new data.")
            st.rerun()

    st.markdown("### Session")
    st.caption("Resetting clears the loaded dataset, trained model, and history for this session.")
    if st.button("Reset Entire Session"):
        reset_session()
        st.rerun()

    st.markdown("### About")
    st.write(
        "This dashboard accompanies the AI-Powered Intrusion Detection System project "
        "(Information Security, CLO 4). It trains and evaluates classifiers on "
        "CIC-IDS2017-style network flow data entirely in memory for this browser session; "
        "nothing is written to disk or sent anywhere outside your machine."
    )
