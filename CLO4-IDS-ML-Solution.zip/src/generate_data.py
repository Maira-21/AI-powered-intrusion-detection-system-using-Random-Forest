"""
generate_data.py
-----------------
Generates a synthetic network-flow dataset that mirrors the structure,
feature set, class taxonomy, and known data-quality quirks of the real
CIC-IDS2017 dataset (CICFlowMeter-extracted flow features; infinite
values in rate features when Flow Duration = 0; heavy class imbalance
toward BENIGN traffic).

This stand-in is used ONLY because the real CIC-IDS2017 CSVs
(several GB, hosted by the Canadian Institute for Cybersecurity,
UNB) cannot be downloaded inside this offline build environment.
The preprocessing / EDA / modeling pipeline in the notebook is written
to run unmodified against the real CIC-IDS2017 CSV files -- see
README.md "Using the real CIC-IDS2017 dataset" section.
"""

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

N_BENIGN = 16000
ATTACK_CLASSES = {
    "DDoS": 1400,
    "PortScan": 1200,
    "DoS Hulk": 900,
    "Bot": 500,
    "FTP-Patator": 400,
    "SSH-Patator": 350,
    "Web Attack - Brute Force": 180,
    "Web Attack - XSS": 120,
    "Infiltration": 60,
}

NUMERIC_FEATURES = [
    "Destination Port",
    "Flow Duration",
    "Total Fwd Packets",
    "Total Backward Packets",
    "Total Length of Fwd Packets",
    "Total Length of Bwd Packets",
    "Fwd Packet Length Mean",
    "Bwd Packet Length Mean",
    "Flow Bytes/s",
    "Flow Packets/s",
    "Flow IAT Mean",
    "Flow IAT Std",
    "Fwd IAT Mean",
    "Bwd IAT Mean",
    "Min Packet Length",
    "Max Packet Length",
    "Packet Length Mean",
    "Packet Length Std",
    "SYN Flag Count",
    "ACK Flag Count",
    "PSH Flag Count",
    "Average Packet Size",
    "Subflow Fwd Bytes",
    "Active Mean",
    "Idle Mean",
]

PROTOCOLS = ["TCP", "UDP", "ICMP"]


def _base_profile(n, loc_scale, spread, protocol_weights):
    """Draw a block of correlated, log-normal-ish flow features for one class."""
    data = {}
    base = RNG.normal(loc=0, scale=1, size=(n, len(NUMERIC_FEATURES)))
    # give features mild correlation via a shared latent factor
    latent = RNG.normal(0, 1, size=n)
    for i, feat in enumerate(NUMERIC_FEATURES):
        col = base[:, i] * spread[i] + latent * 0.3 * spread[i] + loc_scale[i]
        data[feat] = col
    df = pd.DataFrame(data)
    df["Protocol"] = RNG.choice(PROTOCOLS, size=n, p=protocol_weights)
    return df


def generate_raw_dataset():
    frames = []

    # --- BENIGN traffic profile ---
    loc = RNG.uniform(50, 500, size=len(NUMERIC_FEATURES))
    spread = RNG.uniform(20, 120, size=len(NUMERIC_FEATURES))
    benign = _base_profile(N_BENIGN, loc, spread, [0.75, 0.20, 0.05])
    benign["Label"] = "BENIGN"
    frames.append(benign)

    # --- Attack profiles: shifted + tighter/looser spread per class ---
    for cls, n in ATTACK_CLASSES.items():
        shift = RNG.uniform(60, 260, size=len(NUMERIC_FEATURES))
        loc_c = loc + shift * RNG.choice([-1, 1], size=len(NUMERIC_FEATURES))
        spread_c = spread * RNG.uniform(0.7, 1.8, size=len(NUMERIC_FEATURES))
        proto_w = [0.3, 0.6, 0.1] if "DoS" in cls or cls == "DDoS" else [0.85, 0.1, 0.05]
        block = _base_profile(n, loc_c, spread_c, proto_w)
        block["Label"] = cls
        frames.append(block)

    df = pd.concat(frames, ignore_index=True)
    df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)

    # Realistic label noise: a small share of flows are mislabeled/ambiguous
    # (borderline traffic, logging errors) -- this keeps the classifier from
    # a trivially perfect separation, matching what is seen on real traffic captures.
    flip_idx = RNG.choice(df.index, size=int(0.0085 * len(df)), replace=False)
    benign_mask = df.loc[flip_idx, "Label"] == "BENIGN"
    df.loc[flip_idx[benign_mask.values], "Label"] = RNG.choice(
        list(ATTACK_CLASSES.keys()), size=benign_mask.sum()
    )
    df.loc[flip_idx[~benign_mask.values], "Label"] = "BENIGN"

    # Realistic data-quality issues seen in the genuine CIC-IDS2017 CSVs:
    # (a) Flow Bytes/s and Flow Packets/s become +/-inf when Flow Duration ~ 0
    zero_duration_idx = RNG.choice(df.index, size=int(0.004 * len(df)), replace=False)
    df.loc[zero_duration_idx, "Flow Duration"] = 0
    df.loc[zero_duration_idx, "Flow Bytes/s"] = np.inf
    df.loc[zero_duration_idx, "Flow Packets/s"] = np.inf

    # (b) A handful of missing sensor readings (NaNs), as in the raw CICFlowMeter export
    for col in ["Flow IAT Std", "Packet Length Std", "Bwd Packet Length Mean"]:
        nan_idx = RNG.choice(df.index, size=int(0.006 * len(df)), replace=False)
        df.loc[nan_idx, col] = np.nan

    # Some magnitude features can't be negative in reality -> clip
    non_negative_cols = [
        "Flow Duration", "Total Fwd Packets", "Total Backward Packets",
        "Total Length of Fwd Packets", "Total Length of Bwd Packets",
        "Min Packet Length", "Max Packet Length", "SYN Flag Count",
        "ACK Flag Count", "PSH Flag Count", "Active Mean", "Idle Mean",
    ]
    for col in non_negative_cols:
        df[col] = df[col].clip(lower=0)

    df["Destination Port"] = RNG.choice(
        [80, 443, 21, 22, 23, 3389, 8080, 53, 25, 3306], size=len(df)
    )

    ordered_cols = ["Destination Port", "Protocol"] + [
        c for c in NUMERIC_FEATURES if c != "Destination Port"
    ] + ["Label"]
    return df[ordered_cols]


if __name__ == "__main__":
    df = generate_raw_dataset()
    # Run this script from the repo root: python3 src/generate_data.py
    out_path = "data/network_traffic_raw.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df):,} rows x {df.shape[1]} columns to {out_path}")
    print(df["Label"].value_counts())
