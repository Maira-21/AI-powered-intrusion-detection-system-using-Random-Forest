const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, AlignmentType, ImageRun, BorderStyle, PageBreak,
  Header, Footer, PageNumber, LevelFormat, convertInchesToTwip,
} = require("docx");

const FIGS = "../figures";  // run this script from src/: node create_report.js

function imgBuf(name) {
  return fs.readFileSync(`${FIGS}/${name}`);
}

function heading1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 300, after: 150 } });
}
function heading2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 100 } });
}
function body(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 120 },
    alignment: AlignmentType.JUSTIFIED,
  });
}
function bullet(text, level = 0) {
  return new Paragraph({
    children: [new TextRun(text)],
    bullet: { level },
    spacing: { after: 60 },
  });
}
function caption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 20 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  });
}
function centeredImage(name, widthIn, heightIn) {
  return new Paragraph({
    children: [
      new ImageRun({
        data: imgBuf(name),
        transformation: { width: widthIn * 96, height: heightIn * 96 },
        type: "png",
      }),
    ],
    alignment: AlignmentType.CENTER,
    spacing: { after: 60 },
  });
}

function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({ children: [new TextRun({ text, bold: !!opts.bold })], alignment: opts.align || AlignmentType.LEFT })],
    width: { size: opts.width || 2500, type: WidthType.DXA },
    shading: opts.shade ? { type: ShadingType.CLEAR, color: "auto", fill: opts.shade } : undefined,
    verticalAlign: "center",
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
  });
}

function metricsTable() {
  const rows = [
    ["Metric", "Score", "Security Interpretation"],
    ["Accuracy", "99.13%", "Overall share of flows correctly classified"],
    ["Precision", "98.83%", "Of flows flagged as attacks, how many truly were attacks"],
    ["Recall (Sensitivity)", "97.61%", "Of all real attacks, how many were successfully caught"],
    ["F1 Score", "98.21%", "Harmonic balance of precision and recall"],
    ["ROC AUC", "98.72%", "Model's ability to separate benign from malicious flows"],
  ];
  const widths = [2600, 1600, 5000];
  return new Table({
    width: { size: 9200, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      children: r.map((t, j) => cell(t, { bold: i === 0, shade: i === 0 ? "1F4E78" : undefined, width: widths[j] })),
    })),
  });
}

function confusionTable() {
  const rows = [
    ["", "Predicted: BENIGN", "Predicted: ATTACK"],
    ["Actual: BENIGN", "3,967 (TN)", "15 (FP)"],
    ["Actual: ATTACK", "31 (FN)", "1,265 (TP)"],
  ];
  const widths = [2600, 3300, 3300];
  return new Table({
    width: { size: 9200, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      children: r.map((t, j) => cell(t, { bold: i === 0 || j === 0, shade: (i === 0 || j === 0) ? "D9E2F3" : undefined, width: widths[j] })),
    })),
  });
}

function preprocessingTable() {
  const rows = [
    ["Step", "Technique Applied", "Purpose"],
    ["Missing values", "inf -> NaN, then column-median imputation", "Handle CICFlowMeter divide-by-zero artifacts (Flow Bytes/s, Flow Packets/s) robustly against outlier skew"],
    ["Categorical encoding", "LabelEncoder on Protocol (TCP/UDP/ICMP)", "Convert non-numeric feature into a model-usable numeric form"],
    ["Feature scaling", "StandardScaler (zero mean, unit variance)", "Normalize feature magnitudes for pipeline consistency and future model comparability"],
    ["Train/test split", "75% / 25%, stratified on label", "Preserve class balance in both sets given heavy imbalance"],
  ];
  const widths = [1800, 3600, 3800];
  return new Table({
    width: { size: 9200, type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, i) => new TableRow({
      children: r.map((t, j) => cell(t, { bold: i === 0, shade: i === 0 ? "1F4E78" : undefined, width: widths[j] })),
    })),
  });
}

const titlePage = [
  new Paragraph({ text: "", spacing: { before: 1800 } }),
  new Paragraph({
    children: [new TextRun({ text: "AI-Powered Intrusion Detection System", bold: true, size: 44, color: "1F4E78" })],
    alignment: AlignmentType.CENTER, spacing: { after: 100 },
  }),
  new Paragraph({
    children: [new TextRun({ text: "using Random Forest and the CIC-IDS2017 Dataset", bold: true, size: 32, color: "1F4E78" })],
    alignment: AlignmentType.CENTER, spacing: { after: 600 },
  }),
  new Paragraph({
    children: [new TextRun({ text: "A Machine-Learning Proof-of-Concept for SecureNet Corp.'s Network Intrusion Detection System", italics: true, size: 24 })],
    alignment: AlignmentType.CENTER, spacing: { after: 800 },
  }),
  new Paragraph({ children: [new TextRun({ text: "Project Deliverable - Assignment 1", bold: true, size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 400 } }),
  new Paragraph({ children: [new TextRun({ text: "Name: Mahboob", size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: "Enrollment / Student ID: ______________", size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: "Course: Information Security", size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: "Aligned CLO: 4 - Create solutions to real-life scenarios using security-related tools", size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: "Submission Date: September 2026", size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 1200 } }),
  new Paragraph({ children: [new PageBreak()] }),
];

const execSummary = [
  heading1("Executive Summary"),
  body(
    "SecureNet Corp. faces a constant volume of network intrusions that its firewall-based defenses alone cannot reliably catch. This project delivers a proof-of-concept machine-learning classifier that augments the existing Network Intrusion Detection System (NIDS) by automatically labeling network traffic as normal or malicious. Using a dataset modeled on CIC-IDS2017 -- a realistic, labeled capture of benign traffic alongside DDoS, port-scanning, brute-force, web-attack, botnet, and infiltration traffic -- a Random Forest classifier was trained on preprocessed, scaled flow-level features. On a held-out test set, the model achieved 99.13% accuracy, 98.83% precision, 97.61% recall, and a 98.21% F1 score, with only 15 false positives and 31 false negatives out of 5,278 evaluated flows. These results indicate the model catches the large majority of malicious flows while keeping nuisance alerts low, supporting its use as a complementary detection layer alongside SecureNet's existing NIDS rather than a standalone replacement."
  ),
];

const intro = [
  heading1("1. Introduction & Real-World Scenario"),
  body(
    "Traditional perimeter defenses such as firewalls enforce static rules and cannot adapt to novel or subtly disguised attack traffic. As a security analyst at SecureNet Corp., the objective of this project is to evaluate whether a supervised machine-learning model can act as an intelligent, adaptive line of defense that flags malicious network flows the moment they occur, rather than after damage is already done."
  ),
  body(
    "The specific brief from the CISO is to design, develop, and evaluate a proof-of-concept ML model that classifies network traffic as normal or malicious, using a dataset that simulates real-world network conditions. This report documents that full lifecycle: dataset selection and justification, data preprocessing, exploratory analysis, model training, rigorous evaluation, and a security-focused interpretation of what the results mean operationally for a Security Operations Center (SOC)."
  ),
];

const methodology = [
  heading1("2. Methodology"),
  heading2("2.1 Dataset and Scenario Justification"),
  body(
    "The CIC-IDS2017 dataset (Canadian Institute for Cybersecurity, University of New Brunswick) was selected as the basis for this project. It was generated on a fully instrumented network testbed over five days and contains realistic, labeled benign traffic alongside modern attack families directly relevant to a web-facing organization such as SecureNet Corp.:"
  ),
  bullet("DDoS and DoS floods (e.g., DoS Hulk) -- availability attacks against web servers"),
  bullet("PortScan -- reconnaissance preceding a targeted intrusion attempt"),
  bullet("Brute-Force credential attacks (FTP-Patator, SSH-Patator)"),
  bullet("Web Attacks (Brute Force, XSS) -- application-layer threats"),
  bullet("Bot and Infiltration -- post-compromise and internal-threat activity"),
  body(
    "Unlike the outdated KDD'99/NSL-KDD benchmarks, CIC-IDS2017 traffic is exported as bidirectional flow records via CICFlowMeter (duration, packet counts, inter-arrival times, flag counts, and related statistics per flow), matching what a real NetFlow/IPFIX-based sensor would feed into a production detection pipeline. Its heavy natural imbalance toward benign traffic also stress-tests a classifier the way live traffic would, rather than an artificially balanced toy dataset."
  ),
  body(
    "Because the full published dataset is several gigabytes and requires a manual download from the UNB source, the accompanying notebook and the results in this report were produced on a locally generated dataset engineered to match CIC-IDS2017's exact schema, class taxonomy, class imbalance, and known data-quality artifacts (e.g., infinite values in rate-based features when Flow Duration = 0). The pipeline is written to run unmodified against the genuine CIC-IDS2017 CSV files -- see the GitHub README for the one-line setup to substitute the real dataset."
  ),
  heading2("2.2 Data Preprocessing"),
  body("Three preprocessing stages were applied prior to modeling, summarized below:"),
  preprocessingTable(),
  new Paragraph({ text: "", spacing: { after: 120 } }),
  body(
    "Exploratory Data Analysis (EDA) was conducted before cleaning to characterize the traffic the way a security analyst would review SIEM and firewall logs: examining the class distribution, the benign/attack split, protocol mix, and flow-duration patterns. Figure 1 shows the overall benign-versus-malicious split used to frame why precision and recall -- not raw accuracy -- are the metrics that matter most on this heavily imbalanced traffic."
  ),
  centeredImage("fig2_binary_split.png", 3.0, 3.1),
  caption("Figure 1. Overall benign vs. malicious traffic split in the evaluation dataset."),
  heading2("2.3 Machine Learning Model Design: Why Random Forest"),
  body("Random Forest was selected as the classification algorithm for this proof-of-concept for several reasons directly relevant to network intrusion detection:"),
  bullet("Handles the mixed, non-linear relationships typical of flow-based network features without manual feature engineering."),
  bullet("Robust to the correlated/redundant features common in CICFlowMeter exports, since each tree only considers a random feature subset per split."),
  bullet("Combined with class_weight=\"balanced\", copes well with the heavy class imbalance between benign and attack traffic."),
  bullet("Resistant to outliers and does not strictly require scaled inputs, giving a strong baseline with minimal tuning."),
  bullet("Produces interpretable feature importances, letting a SOC understand why a flow was flagged."),
  bullet("Trains and predicts quickly at scale, which matters for near-real-time detection."),
  bullet("Consistently one of the strongest published baselines on CIC-IDS2017 in the intrusion-detection literature."),
];

const results = [
  heading1("3. Results and Security Analysis"),
  heading2("3.1 Performance Metrics"),
  body("The Random Forest classifier (200 trees, max depth 18, class_weight=\"balanced\") was evaluated on a stratified 25% held-out test set (5,278 flows):"),
  metricsTable(),
  new Paragraph({ text: "", spacing: { after: 160 } }),
  heading2("3.2 Confusion Matrix"),
  confusionTable(),
  new Paragraph({ text: "", spacing: { after: 160 } }),
  centeredImage("fig6_confusion_matrix.png", 3.2, 2.75),
  caption("Figure 2. Confusion matrix on the held-out test set."),
  centeredImage("fig7_roc_curve.png", 3.4, 2.9),
  caption("Figure 3. ROC curve (AUC = 0.9872) showing strong separation between benign and malicious traffic."),
  heading2("3.3 Feature Importance"),
  body(
    "The features the model relied on most -- flow byte/packet volume asymmetry (Subflow Fwd Bytes), inter-arrival-time variability (Flow IAT Std), and backward packet counts -- align with known behavioral signatures of automated attack tools (scanners and flooders produce far more regular, asymmetric traffic than human-driven sessions), which supports the model's decisions being grounded in genuine security-relevant signal rather than spurious correlations."
  ),
  centeredImage("fig8_feature_importance.png", 4.2, 3.35),
  caption("Figure 4. Top features driving the Random Forest's classification decisions."),
  heading2("3.4 Security-Focused Interpretation"),
  body(
    "False Positives (15 benign flows flagged as attacks): each is an alert a SOC analyst must triage. At production scale, a high false-positive rate causes alert fatigue -- analysts begin de-prioritizing or ignoring the tool's alerts, which risks a genuine attack being dismissed as noise. If paired with automated blocking, false positives can also disrupt legitimate business traffic."
  ),
  body(
    "False Negatives (31 attacks missed): this is the more dangerous failure mode for a NIDS, since a missed DDoS or brute-force attempt proceeds unopposed. This is why recall on the attack class is weighted more heavily than overall accuracy when judging a security tool's real-world value -- a model can report high accuracy on imbalanced traffic while still missing a concerning share of attacks, simply because attacks are the minority class."
  ),
  body(
    "Read together, the low false-negative rate (2.39% of true attacks) combined with a very low false-positive rate (0.38% of true benign flows) represents a favorable operating point: the model catches the large majority of malicious flows without overwhelming the SOC with nuisance alerts. Recommended deployment posture is to run this classifier in parallel with the existing signature-based NIDS -- routing high-confidence attack predictions to automated rate-limiting and routing borderline-confidence predictions to analyst review -- bounding the operational impact of both error types while the model is validated further on live traffic."
  ),
];

const conclusion = [
  heading1("4. Conclusion and Future Enhancements"),
  body(
    "This project delivered a complete, reproducible pipeline -- from raw flow data to an evaluated proof-of-concept classifier -- demonstrating that Random Forest can distinguish malicious from benign network traffic with high accuracy, precision, and recall on CIC-IDS2017-style data. The security analysis ties these metrics back to their operational meaning for a SOC, directly addressing SecureNet Corp.'s brief to explore ML as an augmentation to its existing NIDS."
  ),
  body("Future enhancements identified for a production-track version of this tool include:"),
  bullet("Multiclass classification of the specific attack family (DDoS vs. PortScan vs. Brute-Force, etc.) so the SOC receives an actionable label, not just a binary flag."),
  bullet("Hyperparameter tuning (GridSearchCV/RandomizedSearchCV) and cross-validation for a more rigorous generalization estimate than a single train/test split."),
  bullet("Class-imbalance techniques beyond class_weight -- SMOTE/ADASYN oversampling of rare attack classes (Infiltration, Web Attacks) to improve recall on the hardest-to-detect categories."),
  bullet("Deep learning approaches (LSTM/1D-CNN on packet sequences, autoencoders for anomaly-based zero-day detection) as a complement to this supervised approach."),
  bullet("Streaming/online deployment with periodic retraining to counter concept drift, benchmarked against real-time throughput requirements."),
  bullet("Explainability tooling (SHAP values) to give analysts a feature-level explanation for each alert, speeding up triage."),
  bullet("Validation against the full, real CIC-IDS2017 dataset and live production traffic samples before any production rollout."),
];

const references = [
  heading1("References"),
  body("Sharafaldin, I., Lashkari, A. H., & Ghorbani, A. A. (2018). Toward Generating a New Intrusion Detection Dataset and Intrusion Traffic Characterization. Proceedings of the 4th International Conference on Information Systems Security and Privacy (ICISSP), 108-116."),
  body("Canadian Institute for Cybersecurity, University of New Brunswick. CIC-IDS2017 Dataset. https://www.unb.ca/cic/datasets/ids-2017.html"),
  body("Breiman, L. (2001). Random Forests. Machine Learning, 45(1), 5-32."),
  body("Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825-2830."),
  new Paragraph({ text: "", spacing: { after: 200 } }),
  heading1("GitHub Repository"),
  body("Source code, the executed Jupyter Notebook, dataset setup instructions, and README: https://github.com/<your-username>/CLO4-IDS-ML-Solution"),
];

const doc = new Document({
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, bottom: 1080, left: 1080, right: 1080 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            children: [new TextRun({ text: "AI-Powered IDS using Random Forest - CIC-IDS2017", size: 16, color: "808080" })],
            alignment: AlignmentType.CENTER,
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            children: [new TextRun({ text: "Page ", size: 18 }), new TextRun({ children: [PageNumber.CURRENT], size: 18 })],
            alignment: AlignmentType.CENTER,
          })],
        }),
      },
      children: [
        ...titlePage,
        ...execSummary,
        ...intro,
        ...methodology,
        ...results,
        ...conclusion,
        ...references,
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("../report/Report_AI_Powered_IDS_RandomForest_CICIDS2017.docx", buf);
  console.log("Report written.");
});
