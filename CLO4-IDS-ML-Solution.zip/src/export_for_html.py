import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_auc_score, roc_curve,
)

RNG_SEED = 42

# ----------------------------------------------------------------------
# 1. Load + preprocess (identical to the notebook pipeline)
# ----------------------------------------------------------------------
df = pd.read_csv("data/network_traffic_raw.csv")
df.columns = [c.strip() for c in df.columns]

raw_label_counts = df["Label"].value_counts().to_dict()
raw_protocol_counts = df["Protocol"].value_counts().to_dict()
n_missing_before = int(df.replace([np.inf, -np.inf], np.nan).isna().sum().sum())

df.replace([np.inf, -np.inf], np.nan, inplace=True)
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

medians = {}
for col in numeric_cols:
    med = float(df[col].median())
    medians[col] = med
    if df[col].isna().any():
        df[col] = df[col].fillna(med)

protocol_encoder = LabelEncoder()
df["Protocol_enc"] = protocol_encoder.fit_transform(df["Protocol"])
df["Binary_Label"] = np.where(df["Label"] == "BENIGN", 0, 1)

feature_cols = numeric_cols + ["Protocol_enc"]
X = df[feature_cols]
y = df["Binary_Label"]

scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.25, random_state=RNG_SEED, stratify=y
)

# ----------------------------------------------------------------------
# 2. Train
# ----------------------------------------------------------------------
clf = RandomForestClassifier(
    n_estimators=200, max_depth=18, min_samples_leaf=2,
    class_weight="balanced", random_state=RNG_SEED, n_jobs=-1,
)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
y_proba = clf.predict_proba(X_test)[:, 1]

metrics = {
    "accuracy": accuracy_score(y_test, y_pred),
    "precision": precision_score(y_test, y_pred),
    "recall": recall_score(y_test, y_pred),
    "f1": f1_score(y_test, y_pred),
    "auc": roc_auc_score(y_test, y_proba),
    "n_train": int(len(X_train)),
    "n_test": int(len(X_test)),
}
cm = confusion_matrix(y_test, y_pred)
tn, fp, fn, tp = [int(v) for v in cm.ravel()]

fpr, tpr, _ = roc_curve(y_test, y_proba)
# Downsample ROC points for a compact but smooth curve
roc_idx = np.linspace(0, len(fpr) - 1, min(120, len(fpr))).astype(int)
roc_points = [{"fpr": float(fpr[i]), "tpr": float(tpr[i])} for i in roc_idx]

importances = pd.Series(clf.feature_importances_, index=feature_cols).sort_values(ascending=False)
top_importances = [{"feature": k, "importance": float(v)} for k, v in importances.head(15).items()]

print("Metrics:", metrics)
print("Confusion:", tn, fp, fn, tp)

# ----------------------------------------------------------------------
# 3. Export forest structure (compact arrays per tree)
# ----------------------------------------------------------------------
def export_tree(tree):
    t = tree.tree_
    feature = t.feature.tolist()
    threshold = [round(float(v), 5) for v in t.threshold]
    left = t.children_left.tolist()
    right = t.children_right.tolist()
    # probability of class 1 (ATTACK) at each node, from the value array
    value = t.value.reshape(t.node_count, -1)
    prob1 = (value[:, 1] / value.sum(axis=1)).tolist()
    prob1 = [round(float(p), 4) for p in prob1]
    return {"f": feature, "t": threshold, "l": left, "r": right, "p": prob1}


forest_export = [export_tree(est) for est in clf.estimators_]
total_nodes = sum(len(t["f"]) for t in forest_export)
print(f"Exported {len(forest_export)} trees, {total_nodes} total nodes")

# ----------------------------------------------------------------------
# 4. EDA aggregates for the dashboard (computed on the full raw dataset)
# ----------------------------------------------------------------------
df_plot = pd.read_csv("data/network_traffic_raw.csv")
df_plot.columns = [c.strip() for c in df_plot.columns]
df_plot["Class"] = np.where(df_plot["Label"] == "BENIGN", "BENIGN", "ATTACK")
cap = df_plot["Flow Duration"].quantile(0.95)
bins = np.linspace(0, cap, 21)
benign_hist, _ = np.histogram(df_plot.loc[df_plot["Class"] == "BENIGN", "Flow Duration"].clip(upper=cap), bins=bins)
attack_hist, _ = np.histogram(df_plot.loc[df_plot["Class"] == "ATTACK", "Flow Duration"].clip(upper=cap), bins=bins)
duration_hist = {
    "bin_edges": [round(float(b), 1) for b in bins],
    "benign": benign_hist.tolist(),
    "attack": attack_hist.tolist(),
}

# Sample rows for the Data Explorer table (raw, human-readable columns)
sample_cols = ["Destination Port", "Protocol", "Flow Duration", "Total Fwd Packets",
               "Total Backward Packets", "Flow Bytes/s", "Flow Packets/s",
               "SYN Flag Count", "Label"]
sample_df = df_plot[sample_cols].replace([np.inf, -np.inf], None).sample(n=600, random_state=1)
sample_rows = json.loads(sample_df.to_json(orient="records"))

# ----------------------------------------------------------------------
# 5. Assemble final payload
# ----------------------------------------------------------------------
payload = {
    "feature_cols": feature_cols,
    "protocol_classes": protocol_encoder.classes_.tolist(),
    "scaler_mean": [float(v) for v in scaler.mean_],
    "scaler_scale": [float(v) for v in scaler.scale_],
    "medians": medians,
    "metrics": metrics,
    "confusion": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
    "roc_points": roc_points,
    "feature_importance": top_importances,
    "label_counts": raw_label_counts,
    "protocol_counts": raw_protocol_counts,
    "n_rows": int(len(df_plot)),
    "n_missing_before": n_missing_before,
    "duration_hist": duration_hist,
    "sample_rows": sample_rows,
    "forest": forest_export,
    "model_config": {
        "algorithm": "Random Forest",
        "n_estimators": 200,
        "max_depth": 18,
        "min_samples_leaf": 2,
        "class_weight": "balanced",
        "random_state": RNG_SEED,
        "test_size": 0.25,
    },
}

with open("dashboard/html/model_data.json", "w") as f:
    json.dump(payload, f, separators=(",", ":"))

import os
size_mb = os.path.getsize("dashboard/html/model_data.json") / (1024 * 1024)
print(f"Wrote dashboard/html/model_data.json ({size_mb:.2f} MB)")
